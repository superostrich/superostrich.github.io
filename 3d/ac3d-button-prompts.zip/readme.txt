Ace Combat Assault Horizion Legacy+ 
Button prompts 
Ver. 1
https://superostrich.xyz


--------


Installtion:

1. Copy the file you wish to use to %appdata%\Citra\load\textures\000400000015C000  
		(create the folder path if it doesn't already exist)
2. Open Citra
3. Emulation Menu -> Configure -> Graphics -> Enable "Use Custom Textures"
4. Enjoy! 